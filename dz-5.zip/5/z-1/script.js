function counter() {
  let q = 0
  return function (step) {
    q += step
    console.log('Count =', q);
  }
}

let sum = counter()
sum(3)
sum(5)
sum(228)