
let dataFilms = document.querySelector('.dataFilms')
let writeMovie = document.querySelector('.writeMovie')
document.querySelector('.search').addEventListener('click', function () {


  const getData = async () => {
    const response = await fetch(`http://www.omdbapi.com/?s=${writeMovie.value}&page=1&apikey=eeb56d4b&t`)
    const data = await response.json()
    // const name = data
    // const poster = data
    dataFilms.innerHTML = null
    for (let i = 0; i < data.Search.length; i++) {
      const movie = `<li><img src="${data.Search[i].Poster}" class="small-image">
    <h2>${data.Search[i].Title}</h2>
    <p>${data.Search[i].Type}</p>
    <p>${data.Search[i].Year}</p>
    <button class="moreDetails" onclick="moreDetalis(event)">More details</button>
    </li>`

      dataFilms.innerHTML += movie

    }
  }
  getData()
})

function moreDetalis(event) {
  let movieName = event.target.parentElement.childNodes[2].textContent
  console.log(movieName);
  let wrapDetailsWindow = document.querySelector('.wrap-detailsWindow')
  wrapDetailsWindow.style.display = 'block'
  const getData = async () => {
    const response = await fetch(`http://www.omdbapi.com/?i=tt3896198&apikey=eeb56d4b&t=${movieName}&plot=full`)
    const data = await response.json()
    const movie = `
    <div class = "detailsWindow">
      <div class="poster"><img src="${data.Poster}" class = "big-image"></div>
      <div class="info">
       <h1 class="line-1">${data.Title} </h1>
       <p class ="line-2">${data.Rated} ${data.Year} ${data.Genre}</p> 
       <p class ="line-3">${data.Plot}</p>
       <p class ="line-4"><b>Writen by:</b>${data.Writer}</p>
       <p class ="line-5"><b>Directed by:</b>${data.Director}</p>
       <p class ="line-6"><b>Starring:</b>${data.Actors}</p>
       <p class ="line-7"><b>BoxOffice:</b>${data.BoxOffice}</p>
       <p class ="line-8"><b>Awards:</b>${data.Awards}</p>
       <p class ="line-9"><b>Ratings:</b>${data.Ratings[0].Source} ${data.Ratings[0].Value}<br>
       ${data.Ratings[1].Source} ${data.Ratings[1].Value}<br>${data.Ratings[2].Source} ${data.Ratings[2].Value}</p>
      </div>
    </div>
      `

    wrapDetailsWindow.innerHTML = movie
    console.log(data)
  }
  getData()
}
let wrapDetailsWindow = document.querySelector('.wrap-detailsWindow')
let moreDetails = document.querySelector('.moreDetails')
document.addEventListener('mousedown', (e) => {
  if (wrapDetailsWindow.style.display != 'none') {
    const withinBoundaries = e.composedPath().includes(wrapDetailsWindow);
    const withinBoundaries2 = e.composedPath().includes(moreDetails)
    if (!withinBoundaries && !withinBoundaries2) {
      wrapDetailsWindow.style.display = 'none';
    }
  }
})
