
const storage = (function () {
  let bank = 1000
  let bearCount = 100
  let wineCount = 50
  let pepsiCount = 80

  let priceBear = 30
  let priceWine = 90
  let pricePepsi = 20

  function checkBank(){
    return `Bank : ${bank}`
  }

  function sellBear (count) {
    if (count <= bearCount){
      bearCount-=count
      bank += count * priceBear 
      return bearCount
    }
    return `Вибачте, але на складі залишилось пива ${bearCount} штук`
  }

  function sellWine(count) {
    if (count <= wineCount) {
      wineCount -= count
      bank += count * priceWine
      return wineCount
    }
    return `Вибачте, але на складі залишилось пива ${wineCount} штук`
  }
  function sellPepsi(count) {
    if (count <= pepsiCount) {
      pepsiCount -= count
      bank += count * pricePepsi
      return pepsiCount
    }
    return `Вибачте, але на складі залишилось пива ${pepsiCount} штук`
  }
return{
  bear: sellBear,
  wine: sellWine,
  pepsi: sellPepsi,
  bank: checkBank
  
}

}())

console.log(`На складі залишилось  ${storage.bear(10)}  шт. пива`); 
console.log(`На складі залишилось  ${storage.wine(5)}  шт. вина `);
console.log(`На складі залишилось  ${storage.pepsi(20)}  шт. пепсі `);
console.log(`${storage.bank()} грн`);
console.log(`На складі залишилось  ${storage.bear(3)}  шт. пива`);
console.log(`${storage.bank()} грн`);









