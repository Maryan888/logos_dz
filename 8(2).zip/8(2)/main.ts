//Завдання 1
let city: string = 'Київ'
city = 'Львів'
let adress: string = city
console.log(adress);


// //Завдання 2
// let num: any = prompt('Напишіть число')
// num == 0 ? console.log('Число 0') :
//   num % 2 != 0 ? console.log('Число непарне') :
//     console.log('Число парне')



// //Завдання 3
// function maxNum(...arg: Array<number>) {
//   return Math.max.apply(null, arg)
// }
// console.log(maxNum(6, 1, 5, 4,123,23,12));



// //Завдання 4
// function getSqrt(number:number): void {
//   if (number>0) {
//    console.log(`Квадратний корінь з ${number} дорівнює ${Math.sqrt(number)}`);
//   }

//   else if (number<0){
//     console.log('Введіть додатнє число')
//   }
//   else if(number==undefined){
//     console.log('В функцію нічого не передали')
//   }
//   else if(isNaN(number)){
//     console.log('Повинно бути числове значення');
//   }
// }
// getSqrt(-8)




// // завд5
// let badWords = document.querySelector('.badWords') as HTMLDivElement
// let writeBadWord = document.querySelector('.writeBadWord') as HTMLInputElement
// function add(): void {
//   if (writeBadWord.value == '') {
//     writeBadWord.placeholder = 'Please write a word!'
//     writeBadWord.style.borderColor = 'red'
//   }
//   else if (badWords.textContent == '') {
//     badWords.textContent += writeBadWord.value
//     writeBadWord.placeholder = 'word here..'
//     writeBadWord.style.borderColor = 'lightGrey'

//   }
//   else if (badWords.textContent != '') {
//     badWords.textContent += ',' + writeBadWord.value
//     writeBadWord.placeholder = 'word here..'
//     writeBadWord.style.borderColor = 'lightGrey'

//   }
//   writeBadWord.value = ""
// }

// function reset(): any {
//   badWords.textContent = ''
// }

// let writeText = document.querySelector('.writeText') as HTMLInputElement

// function cenzor(): void {
//   let arr: any = badWords.textContent?.split(',')
//   console.log(arr)
//   if (writeText.value == '') {
//     writeText.placeholder = 'Please write a text!'
//   }
//   else {
//     for (let i = 0; i < arr.length; i++) {
//       if (badWords.textContent != '') {

//         let lastIndStr = writeText.value.lastIndexOf(arr[i])
//         let indStr = writeText.value.indexOf(arr[i])
//         let a = arr[i]
//         let newStr: string
//         let b: any = '*'
//         if (indStr !== (-1) ) {
//           console.log(arr[i])
//           for (let n = 1; n < a.length; n++) {
//             b += '*'
//           }
//           newStr = writeText.value.replace(arr[i], b)
//           writeText.value = newStr
//         }
        
//         else {

//         }
//       }
//     }
//   }

// }
