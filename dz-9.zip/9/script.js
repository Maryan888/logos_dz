let qs = qs => document.querySelector(qs);
function add() {
    if (qs('.add').textContent != 'Edit user') {
        let newRow = qs('tbody').insertRow(-1);
        let cell1 = newRow.insertCell(0);
        let cell2 = newRow.insertCell(1);
        let cell3 = newRow.insertCell(2);
        let cell4 = newRow.insertCell(3);
        let cell5 = newRow.insertCell(4);
        let cell6 = newRow.insertCell(5);
        for (let i = 0; i < qs('tbody').rows.length; i++) {
            cell1.innerHTML = i + 1;
        }
        cell2.textContent = qs('.login').value;
        cell3.textContent = qs('.password').value;
        cell4.textContent = qs('.email').value;
        cell5.innerHTML = '<button class = "edit"  onclick = "editUser(this)">Edit</button>';
        cell6.innerHTML = '<button class = "delete"  onclick = "deleteUser(this)">Delete</button>';
        qs('.login').value = '';
        qs('.password').value = '';
        qs('.email').value = '';
        qs('.add').textContent = 'Add user';
    }
    else {
        qs('.add').style.border = '1px solid red';
    }
}
qs('.add').addEventListener('focus', function () {
    qs('.add').style.border = '2px solid green';
});
qs('.add').addEventListener('blur', function () {
    qs('.add').style.border = '1px solid lightgreen';
});
function deleteUser(r) {
    let i = r.parentNode.parentNode.rowIndex;
    qs('tbody').deleteRow(i - 1);
    for (let j = 0; j < qs('tbody').rows.length; j++) {
        qs('tbody').rows[j].children[0].textContent = j + 1;
    }
}
function editUser(e) {
    let i = e.parentNode.parentNode.rowIndex;
    let result1 = qs('tbody').children[i - 1].children[1].textContent;
    let result2 = qs('tbody').children[i - 1].children[2].textContent;
    let result3 = qs('tbody').children[i - 1].children[3].textContent;
    qs('.login').value = result1;
    qs('.password').value = result2;
    qs('.email').value = result3;
    qs('.add').textContent = 'Edit user';
    qs('.add').addEventListener('click', function (event) {
        if (qs('.add').textContent == 'Edit user') {
            qs('tbody').children[i - 1].children[1].textContent = qs('.login').value;
            qs('tbody').children[i - 1].children[2].textContent = qs('.password').value;
            qs('tbody').children[i - 1].children[3].textContent = qs('.email').value;
            qs('.add').textContent = 'Add user';
            qs('.login').value = '';
            qs('.password').value = '';
            qs('.email').value = '';
        }
    });
}
