
let firstName = document.querySelector('.firstName')
let secondName = document.querySelector('.secondName')
let email = document.querySelector('.email')
let password = document.querySelector('.password')
let email2 = document.querySelector('.email2')
let password2 = document.querySelector('.password2')
let data = []
let signIn = document.querySelector('.signIn')

let firstNameReg = /^\w{1,20}\D$/
let secondNameReg = /^\w{1,20}\D$/
let emailReg = /^[a-zA-Z0-9-.]+\@[a-zA-Z]+\.[a-zA-Z]+$/
let passwordReg = /^\w{5,15}$/

document.querySelector('.signUp').addEventListener('click', function () {
  let testFirstName = firstNameReg.test(firstName.value)
  let testLastName = secondNameReg.test(secondName.value)
  let testEmail = emailReg.test(email.value)
  let testPassword = passwordReg.test(password.value)
  if (testFirstName && testLastName && testEmail && testPassword) {
    if (!data.some(filling => filling.toLowerCase() === email.value.toLowerCase())) {
      document.querySelector('.error1').style.display = 'none'
      document.querySelector('.error2').style.display = 'none'
      document.querySelector('.error3').style.display = 'none'
      document.querySelector('.error4').style.display = 'none'
      if (localStorage.length > 0 && localStorage.getItem('data')) {
        data = JSON.parse(localStorage.getItem('data'))
      }
      data.push(firstName.value)
      data.push(secondName.value)
      data.push(email.value)
      data.push(password.value)

      localStorage.setItem('data', JSON.stringify(data))
      firstName.value = ''
      secondName.value = ''
      email.value = ''
      password.value = ''
    }
    else {
      document.querySelector('.error3').style.display = 'block'
      document.querySelector('.errorEmail1').textContent = 'This email already exist'
    }
  }


  else {
    if (testFirstName == false) {
      document.querySelector('.error1').style.display = 'block'
      document.querySelector('.errorFirstName').textContent = 'First name is not correct'
    }
    if (testLastName == false) {
      document.querySelector('.error2').style.display = 'block'
      document.querySelector('.errorSecondName').textContent = 'Second name is not correct'
    }
    if (testEmail == false) {
      document.querySelector('.error3').style.display = 'block'
      document.querySelector('.errorEmail1').textContent = 'Email is not correct'
    }
    if (testPassword == false) {
      document.querySelector('.error4').style.display = 'block'
      document.querySelector('.errorPassword').textContent = 'Password is not correct'
    }



    if (testFirstName == true) {
      document.querySelector('.error1').style.display = 'none'
      document.querySelector('.errorFirstName').textContent = 'First name is not correct'
    }
    if (testLastName == true) {
      document.querySelector('.error2').style.display = 'none'
      document.querySelector('.errorSecondName').textContent = 'Second name is not correct'
    }
    if (testEmail == true) {
      document.querySelector('.error3').style.display = 'none'
    }
    if (testPassword == true) {
      document.querySelector('.error4').style.display = 'none'
      document.querySelector('.errorPassword').textContent = 'Password is not correct'

    }
  }
  console.log(data)
})






signIn.addEventListener('click', function () {
  let testEmail = emailReg.test(email2.value)

  if (testEmail == true && data.some(filling => filling.toLowerCase() === email2.value.toLowerCase()) &&
    data.some(filling => filling.toLowerCase() === password2.value.toLowerCase()) &&
    password2.value.toLowerCase() === data[data.indexOf(email2.value.toLowerCase()) + 1]) {
    document.querySelector('.result-firstName').textContent = data[data.indexOf(email2.value.toLowerCase()) - 2]
    document.querySelector('.result-secondName').textContent = data[data.indexOf(email2.value.toLowerCase()) - 1]
    document.querySelector('.error6').style.display = 'none'
    document.querySelector('.logining').style.display = 'none'
    document.querySelector('.result').style.display = 'block'
    email2.value = ''
    password2.value = ''
  }
  else {
    document.querySelector('.error6').style.display = 'block'
    document.querySelector('.errorPassword2').textContent = 'Incorect email or password'
  }
})


document.querySelector('.goToLogining').addEventListener('click', function () {
  document.querySelector('.register').style.display = 'none'
  document.querySelector('.logining').style.display = 'block'

})
document.querySelector('.signUp2').addEventListener('click', function () {
  document.querySelector('.result').style.display = 'none'
  document.querySelector('.logining').style.display = 'block'

})
document.querySelector('.goToSigning').addEventListener('click', function () {
  document.querySelector('.logining').style.display = 'none'
  document.querySelector('.register').style.display = 'block'
})
